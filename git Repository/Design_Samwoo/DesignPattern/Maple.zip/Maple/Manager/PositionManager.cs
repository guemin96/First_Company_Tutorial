﻿using System;
using System.Collections.Generic;
using System.Text;
using static Maple.GameInstance;

namespace Maple
{
    class Subject
    {
        private List<Observer> observers = new List<Observer>();
        public void Attach(Observer observer)
        {
            observers.Add(observer);
        }
        public void Detach(Observer observer)
        {
            observers.Remove(observer);
        }
        public void Notify()
        {
            foreach (Observer observer in observers)
            {
                observer.Update(this);
            }
        }
        private int mapNum;
        public int MapNum
        {
            get { return mapNum; }
            set
            {
                mapNum = value;
                Notify();
            }
        }

    } 
    interface Observer
    {
        void Update(Subject _subject);
    }
    class PostionObserver : Observer
    {
        private Subject subject;
        public void Update(Subject _subject)
        {
            this.subject = _subject;
            Console.WriteLine("캐릭터가 이동중입니다. 잠시만 기다려주세요!");
            //Console.WriteLine("현재 위치는 {0}입니다", Instance.Position.GetPosition());
            Console.ReadLine();
        }
        public Subject Subject
        {
            get { return subject; }
            set { subject = value; }
        }
    }
    class PositionManager
    {
    }
}
