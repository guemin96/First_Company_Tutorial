﻿using System;
using System.Collections.Generic;
using System.Text;
using static Maple.GameInstance;

namespace Maple
{
    abstract class IGameManager:Subject {
        Subject mapsub = new Subject();
        
       public abstract void Execute();
        public string GetPosition()
        {
            switch (Instance.Position.ToString())
            {
                case "Maple.Perion":
                    return "페리온";
                case "Maple.Ellinia":
                    return "엘리니아";
                case "Maple.Henesis":
                    return "헤네시스";
                case "Maple.CunningCity":
                    return "커닝시티";
                default:
                    break;
            }
            return null;
        }
        public void Move()
        {

            Console.Clear();
            Console.WriteLine("빅토리아로드 {0}에 오신것을 환영합니다.", GetPosition());
            Instance.Subject.Notify();
            Console.WriteLine("갈 곳을 선택하시오. 1)마을 2)칭호");
            string input1 = Console.ReadLine();
            switch (input1)
            {
                case "1":
                    Console.WriteLine("갈 마을을 선택하시오");
                    Console.WriteLine("1)페리온 2)헤네시스 3)엘리니아 4)커닝시티");
                    string input = Console.ReadLine();
                    mapsub.Attach(new PostionObserver());

                    switch (input)
                    {
                        case "1":
                            Instance.Position = new Perion();
                            mapsub.MapNum = 1;
                            break;
                        case "2":
                            Instance.Position = new Henesis();
                            mapsub.MapNum = 2;
                            break;
                        case "3":
                            Instance.Position = new Ellinia();
                            mapsub.MapNum = 3;

                            break;
                        case "4":
                            Instance.Position = new CunningCity();
                            mapsub.MapNum = 4;
                            break;
                    }
                    break;
                case "2":
                    Console.WriteLine("칭호 미구현");
                    break;
                default:
                    break;
            }
        }
    }; 
    //캐릭터 생성 -> 선택 후 나타나야할 부분
    class GameManager
    {
        public GameManager()
        {
           
        }
        public void Execute()
        {
            ShowMenu();

        }
        public void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("{0}의 현재 위치는 {1}입니다.", Instance.Character.Name,GetPosition());
            Console.WriteLine("갈 곳을 선택하시오");
            Console.WriteLine("1.마을 2.칭호 ");

            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    Console.WriteLine("갈 마을을 선택하시오");
                    Console.WriteLine("1)페리온 2)헤네시스 3)엘리니아 4)커닝시티");
                    string v_input = Console.ReadLine();
                    switch (v_input)
                    {
                        case "1":
                            Instance.Position = new Perion();

                            break;
                        case "2":
                            Instance.Position = new Henesis();
                            break;
                        case "3":
                            Instance.Position = new Ellinia();
                            break;
                        case "4":
                            Instance.Position = new CunningCity();
                            break;
                    }
                    break;
                case "2":
                    break;
                case "3":
                    break;
                default:
                    break;
            }
            bool loop = true;
            while (loop)
            {
               // Console.Clear();
                Instance.Position.Execute();
            }
        }

        public string GetPosition()
        {
            switch (Instance.Position.ToString())
            {
                case "Maple.Perion":
                    return "페리온";
                case "Maple.Ellinia":
                    return "엘리니아";
                case "Maple.Henesis":
                    return "헤네시스";
                case "Maple.CunningCity":
                    return "커닝시티";
                default:
                    break;
            }
            return null;
        }
        

    }
}
