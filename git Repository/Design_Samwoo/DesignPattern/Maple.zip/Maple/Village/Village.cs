﻿using System;
using System.Collections.Generic;
using System.Text;
using static Maple.GameInstance;

namespace Maple
{
    class Perion : IGameManager
    {
        public override void Execute()
        {
            
            Move();

            return;
        }
    }
    class Ellinia : IGameManager
    {
        
        public override void Execute()
        {
            Move();
            
            return;
        }
    }
    class Henesis : IGameManager
    {
        public override void Execute()
        {
            Move();

            return;
        }
    }
    class CunningCity : IGameManager
    {
        public override void Execute()
        {
            Move();

            return;
        }
    }
}
